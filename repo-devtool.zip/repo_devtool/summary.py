from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .models import Issue, OperationResult

console = Console()


def _status_text(result: OperationResult) -> Text:
    if result.skipped:
        return Text("skipped", style="yellow")
    if result.returncode == 0:
        return Text("ok", style="green")
    return Text("failed", style="bold red")


def _severity_text(issue: Issue) -> Text:
    style = "yellow" if issue.severity == "warning" else "bold red"
    return Text(issue.severity, style=style)


def _cell(value: str | None) -> Text:
    return Text(value or "-", overflow="fold", no_wrap=False)


def render_summary(results: list[OperationResult]) -> dict[str, int]:
    warnings = sum(1 for result in results for issue in result.issues if issue.severity == "warning")
    errors = sum(1 for result in results for issue in result.issues if issue.severity == "error")
    failures = sum(1 for result in results if result.returncode != 0)
    skipped = sum(1 for result in results if result.skipped)

    op_table = Table(title="Command Summary", show_lines=False)
    op_table.add_column("Command", style="bold")
    op_table.add_column("Status")
    op_table.add_column("Time (s)", justify="right")
    op_table.add_column("Exit", justify="right")
    op_table.add_column("Log")

    for result in results:
        op_table.add_row(
            _cell(result.name),
            _status_text(result),
            Text(f"{result.duration_seconds:.2f}"),
            Text(str(result.returncode)),
            _cell(result.log_path or "-"),
        )

    console.print(op_table)

    issues = [issue for result in results for issue in result.issues]
    if issues:
        issue_table = Table(title="Warnings and Errors", show_lines=False)
        issue_table.add_column("Level")
        issue_table.add_column("Command")
        issue_table.add_column("File")
        issue_table.add_column("Code")
        issue_table.add_column("Message", overflow="fold")
        for issue in issues:
            issue_table.add_row(
                _severity_text(issue),
                _cell(issue.command),
                _cell(issue.file or "-"),
                _cell(issue.code or "-"),
                _cell(issue.message),
            )
        console.print(issue_table)

    summary = Text()
    summary.append("warnings=", style="yellow")
    summary.append(str(warnings), style="bold yellow")
    summary.append("  errors=", style="red")
    summary.append(str(errors), style="bold red")
    summary.append("  failed=", style="red")
    summary.append(str(failures), style="bold red")
    summary.append("  skipped=", style="yellow")
    summary.append(str(skipped), style="bold yellow")
    console.print(Panel(summary, title="Totals", expand=False))

    return {
        "warnings": warnings,
        "errors": errors,
        "failures": failures,
        "skipped": skipped,
    }


def render_status_table(rows: list[tuple[str, str]]) -> None:
    table = Table(title="Status", show_lines=False)
    table.add_column("Field", style="bold")
    table.add_column("Value", overflow="fold")
    for key, value in rows:
        table.add_row(_cell(key), _cell(value))
    console.print(table)


def build_json_summary(results: list[OperationResult], *, repo_root: str) -> dict:
    return {
        "repo_root": repo_root,
        "warnings": sum(1 for r in results for i in r.issues if i.severity == "warning"),
        "errors": sum(1 for r in results for i in r.issues if i.severity == "error"),
        "failures": sum(1 for r in results if r.returncode != 0),
        "skipped": sum(1 for r in results if r.skipped),
        "results": [
            {
                "name": r.name,
                "argv": r.argv,
                "returncode": r.returncode,
                "duration_seconds": r.duration_seconds,
                "log_path": r.log_path,
                "skipped": r.skipped,
                "issues": [
                    {
                        "severity": i.severity,
                        "command": i.command,
                        "file": i.file,
                        "code": i.code,
                        "message": i.message,
                    }
                    for i in r.issues
                ],
            }
            for r in results
        ],
    }
