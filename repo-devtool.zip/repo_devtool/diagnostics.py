from __future__ import annotations

import re
from pathlib import Path

from .models import Issue

_DOTNET_DIAGNOSTIC = re.compile(
    r"^(?P<file>/.+?)\((?P<line>\d+),(?P<col>\d+)(?:,\d+,\d+)?\): "
    r"(?P<severity>warning|error) (?P<code>[A-Za-z]+\d+): (?P<message>.+?)(?: \[.*\])?$"
)

_GCC_CLANG = re.compile(
    r"^(?P<file>[^:\s][^:]*)[:](?P<line>\d+)(?::(?P<col>\d+))?:\s+"
    r"(?P<severity>warning|error|fatal error):\s+(?P<message>.+)$",
    re.IGNORECASE,
)
_PYTEST_FAILURE = re.compile(r"^FAILED\s+(?P<file>[^:]+)(?:::(?P<node>.+))?\s+-\s+(?P<message>.+)$")
_UNITTEST_FAILURE = re.compile(r"^(FAIL|ERROR):\s+.+?\((?P<file>[^)]+)\)$")
_PY_STYLE = re.compile(
    r"^(?P<file>[^:]+):(?P<line>\d+):(?:(?P<col>\d+):)?\s+"
    r"(?P<code>[A-Z]+\d+)?\s*(?P<message>.+)$"
)
_MYPY = re.compile(
    r"^(?P<file>[^:]+):(?P<line>\d+):(?:(?P<col>\d+):)?\s+"
    r"(?P<severity>error|note|warning):\s+(?P<message>.+?)(?:\s+\[(?P<code>[^\]]+)\])?$",
    re.IGNORECASE,
)
_CARGO_RUSTC = re.compile(
    r"^(?P<severity>warning|error)(?:\[(?P<code>E\d+)\])?:\s+(?P<message>.+)$",
    re.IGNORECASE,
)
_CARGO_FILE = re.compile(r"^\s*-->\s+(?P<file>[^:]+):(?P<line>\d+):(?P<col>\d+)$")
_GENERIC_WARN_ERR = re.compile(r"\b(?P<severity>warning|error)\b[: ]+(?P<message>.+)", re.IGNORECASE)


def relativize(repo_root: Path, path_text: str) -> str:
    if not path_text or path_text == "-":
        return "-"
    try:
        path = Path(path_text).expanduser()
        if not path.is_absolute():
            path = (repo_root / path).resolve()
        else:
            path = path.resolve()
        return str(path.relative_to(repo_root))
    except Exception:
        return path_text


def parse_issues(repo_root: Path, command_name: str, output: str) -> list[Issue]:
    issues: list[Issue] = []
    cargo_pending: Issue | None = None

    for line in output.splitlines():
        stripped = line.rstrip()

        match = _DOTNET_DIAGNOSTIC.match(stripped)
        if match:
            issues.append(Issue(
                severity=match.group("severity").lower(),
                command=command_name,
                file=relativize(repo_root, match.group("file")),
                code=match.group("code"),
                message=match.group("message").strip(),
            ))
            continue

        match = _PYTEST_FAILURE.match(stripped)
        if match:
            issues.append(Issue("error", command_name, relativize(repo_root, match.group("file")), "PYTEST", match.group("message").strip()))
            continue

        match = _UNITTEST_FAILURE.match(stripped)
        if match:
            issues.append(Issue("error", command_name, relativize(repo_root, match.group("file")), "UNITTEST", stripped))
            continue

        match = _GCC_CLANG.match(stripped)
        if match:
            sev = match.group("severity").lower()
            if sev == "fatal error":
                sev = "error"
            issues.append(Issue(
                sev,
                command_name,
                relativize(repo_root, match.group("file")),
                "CC",
                match.group("message").strip(),
            ))
            continue

        match = _MYPY.match(stripped)
        if match:
            sev = match.group("severity").lower()
            if sev == "note":
                sev = "warning"
            issues.append(Issue(
                sev,
                command_name,
                relativize(repo_root, match.group("file")),
                (match.group("code") or "MYPY").upper(),
                match.group("message").strip(),
            ))
            continue

        match = _PY_STYLE.match(stripped)
        if match and match.group("code"):
            code = match.group("code").upper()
            sev = "warning"
            if code.startswith(("F", "E9")):
                sev = "error"
            issues.append(Issue(
                sev,
                command_name,
                relativize(repo_root, match.group("file")),
                code,
                match.group("message").strip(),
            ))
            continue

        match = _CARGO_RUSTC.match(stripped)
        if match:
            cargo_pending = Issue(
                match.group("severity").lower(),
                command_name,
                "-",
                match.group("code") or "RUSTC",
                match.group("message").strip(),
            )
            issues.append(cargo_pending)
            continue

        match = _CARGO_FILE.match(stripped)
        if match and cargo_pending is not None:
            cargo_pending.file = relativize(repo_root, match.group("file"))
            continue

        match = _GENERIC_WARN_ERR.search(stripped)
        if match and command_name in {"build", "test", "restore", "package"}:
            issues.append(Issue(
                match.group("severity").lower(),
                command_name,
                "-",
                "GENERIC",
                match.group("message").strip(),
            ))

    return _dedupe_issues(issues)



def _dedupe_issues(issues: list[Issue]) -> list[Issue]:
    seen: set[tuple[str, str, str, str, str]] = set()
    unique: list[Issue] = []
    for issue in issues:
        key = (issue.severity, issue.command, issue.file, issue.code, issue.message)
        if key in seen:
            continue
        seen.add(key)
        unique.append(issue)
    return unique
